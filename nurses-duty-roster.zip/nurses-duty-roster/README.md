# Nurses Duty Roster

A phone app for the ward's nurses duty roster. It looks like the paper sheet and syncs live: when one nurse changes a square, everyone else's phone updates within seconds. Changes made without internet are kept and sync when the phone is back online.

It runs on **GitHub Pages** (the app) and **Firebase Firestore** (the shared roster). Both are free at ward size.

## Files

| File | What it is |
|---|---|
| `index.html` | The whole app. Paste your Firebase settings near the top of its script. |
| `firestore.rules` | Security rules to paste into Firebase. |
| `sw.js` | Lets the app open offline. |
| `manifest.json`, `icon-*.png` | Lets nurses add it to their home screen like an app. |

## Setup (about 15 minutes, all from a phone browser)

### 1. Create the Firebase database
1. Go to **console.firebase.google.com** and choose **Create a project**. Name it, for example, `ward-duty-roster`. Google Analytics can be turned off.
2. In the left menu open **Build → Firestore Database → Create database**.
3. Choose **Start in production mode**.
4. Pick the location **africa-south1 (Johannesburg)**. It's the closest to Malawi, and it can't be changed later.
5. Open the **Rules** tab, delete what's there, paste the whole of `firestore.rules`, then tap **Publish**.

### 2. Get the Firebase settings
1. Tap the gear icon, then **Project settings**.
2. Under **Your apps**, tap the **web** icon (`</>`), give it a nickname, and register it. Hosting is not needed.
3. Firebase shows a `firebaseConfig` block. Copy the six values (`apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, `appId`).

### 3. Put the app on GitHub Pages
1. On github.com create a new **public** repository, for example `duty-roster`.
2. Tap **Add file → Upload files**, upload every file from this folder, and commit.
3. Open `index.html` in the repo and tap the pencil icon to edit. Near the top of the script, fill in `FIREBASE_CONFIG` with the six values. Commit.
4. Go to **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**, branch **main**, folder **/ (root)**, then **Save**.
5. After a minute the app is live at `https://YOUR-USERNAME.github.io/duty-roster/`.

### 4. Start sharing
1. Open the app and tap **Share with the ward → Start sharing**. The roster on that phone goes online and gets an 8-character **ward code**.
2. Tap **Send on WhatsApp** to send the ward link to the nurses. Opening the link joins the ward automatically. Nurses can also type the code under **Join a ward roster**.
3. On Android, the browser menu has **Add to Home screen** (or **Install app**). On iPhone, use **Share → Add to Home Screen**.

## Good to know

- **Who can edit:** anyone with the ward link or code can see and change the roster. There are no logins. Treat the code like a password and keep it in the ward group.
- **"This is my row"** is saved per phone, so each nurse sees her own week at the top.
- **Two people editing:** single squares save one by one, so two nurses changing different squares at the same time never undo each other. If they change the *same* square, the last change wins.
- **Updating the app:** after uploading a new `index.html`, change `duty-roster-v1` in `sw.js` to `-v2` (and so on) so phones load the new version.
- **Photo-to-roster** (reading a picture of the paper sheet) is only in the Claude version of the app, because it uses Claude to read the handwriting.
- **Optional, extra protection:** in Google Cloud Console → **APIs & Services → Credentials**, you can restrict the Firebase API key to your `github.io` address. The ward code is still what protects the roster.
